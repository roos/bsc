app.route.get('/allfile',  async function (req) {
//    return await app.model.Notary.findOne({file: req.params.file})
// load all
  let files = await app.model.Notary.findAll({
    limit: 50,
    offset: 0,
//    sort: {
//      timestamp: -1
//    }
  })
  return files
})

app.route.get('/file/:file', async function(req) {
  return await app.model.Notary.findOne({
    file: req.params.file
  })
})

app.route.get('/user/:user', async function(req) {
  return await app.model.Notary.findOne({
    ownerId: req.params.user
  })
})
