module.exports = {
  add_file: async function(file, description) {
    app.sdb.lock('notary.register@' + file)
    let exists = await app.model.Notary.exists({file: file})
    if (exists) return 'File already registered'
    app.sdb.create('Notary', {
      id: "12345",
      transactionId: "23456",
      file: file,
      description: description,
      ownerId: this.trs.senderId,
      timestamp: "34567"
    })
  }
}

